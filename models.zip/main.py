from fastapi import FastAPI, Depends, HTTPException, status, Request, Form, Response, UploadFile, File
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import time
import asyncio
from typing import List, Dict, Optional, Any
from datetime import datetime
from ai_client import generate_chat_response
from database import engine, get_db
import models
from sqlalchemy.orm import Session
import uuid
import hashlib
import json
import base64
import mimetypes
import os
from passlib.context import CryptContext
from jose import jwt, JWTError

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="ChatGPT Clone API")

app.mount("/static", StaticFiles(directory="static"), name="static")

templates = Jinja2Templates(directory="templates")

# Auth Configuration
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "4324324324324324ewdsa"
ALGORITHM = "HS256"

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict):
    return jwt.encode(data, SECRET_KEY, algorithm=ALGORITHM)

class ChatRequest(BaseModel):
    chat_id: str
    messages: List[Dict[str, Any]]
    title: Optional[str] = None

class ChatSessionCreate(BaseModel):
    id: str
    title: str
    messages: list
    total_tokens: int
    token_limit: int
    locked_until: int
    project_id: Optional[str] = None

class UserUpdate(BaseModel):
    display_name: str
    password: Optional[str] = None

class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = None

class ProjectUpdate(BaseModel):
    name: str
    description: Optional[str] = None

def get_current_user_obj(request: Request, db: Session):
    token = request.cookies.get("session_token")
    if not token:
        return None
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            return None
    except JWTError:
        return None
    user = db.query(models.User).filter(models.User.username == username).first()
    return user

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        return RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    
    # We pass display_name to template
    d_name = user.display_name if user.display_name else user.username
    return templates.TemplateResponse(request=request, name="index.html", context={"user": user.username, "display_name": d_name})

@app.get("/login", response_class=HTMLResponse)
async def login_get(request: Request, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if user:
         return RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(request=request, name="login.html")

@app.post("/login")
async def login_post(response: Response, username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == username).first()
    if not user or not verify_password(password, user.hashed_password):
        return RedirectResponse(url="/login?error=1", status_code=status.HTTP_302_FOUND)
    
    token = create_access_token({"sub": user.username})
    response = RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
    response.set_cookie(key="session_token", value=token, httponly=True)
    return response

@app.get("/register", response_class=HTMLResponse)
async def register_get(request: Request):
    return templates.TemplateResponse(request=request, name="register.html")

@app.post("/register")
async def register_post(request: Request, username: str = Form(...), password: str = Form(...), display_name: str = Form(...), db: Session = Depends(get_db)):
    db_user = db.query(models.User).filter(models.User.username == username).first()
    if db_user:
        return RedirectResponse(url="/register?error=exists", status_code=status.HTTP_302_FOUND)
    
    new_user = models.User(
        id=str(uuid.uuid4()), 
        username=username, 
        display_name=display_name,
        hashed_password=get_password_hash(password)
    )
    db.add(new_user)
    db.commit()
    
    token = create_access_token({"sub": username})
    resp = RedirectResponse(url="/", status_code=status.HTTP_302_FOUND)
    resp.set_cookie(key="session_token", value=token, httponly=True)
    return resp

@app.get("/logout")
async def logout(response: Response):
    response = RedirectResponse(url="/login", status_code=status.HTTP_302_FOUND)
    response.delete_cookie("session_token")
    return response

@app.post("/api/user/update")
async def update_user(request: Request, data: UserUpdate, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    user.display_name = data.display_name
    if data.password:
        user.hashed_password = get_password_hash(data.password)
    db.commit()
    return {"status": "success", "display_name": user.display_name}

def get_query_hash(messages):
    s = json.dumps(messages, sort_keys=True)
    return hashlib.sha256(s.encode('utf-8')).hexdigest()

@app.post("/api/chat")
async def chat_api(request: Request, chat_req: ChatRequest, db_session: Session = Depends(get_db)):
    user = get_current_user_obj(request, db_session)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # Check limit and lock
    chat = db_session.query(models.ChatSession).filter(models.ChatSession.id == chat_req.chat_id).first()
    if chat:
        if chat.total_tokens >= chat.token_limit:
            now_ms = int(time.time() * 1000)
            if chat.locked_until > now_ms:
                raise HTTPException(status_code=403, detail=f"Locked until {chat.locked_until}")
            elif chat.locked_until > 0 and chat.locked_until <= now_ms:
                # Auto Unlock!
                chat.token_limit += 1000
                chat.locked_until = 0
            else:
                chat.locked_until = now_ms + (10 * 60 * 1000)
                raise HTTPException(status_code=403, detail=f"Locked until {chat.locked_until}")
            
    # Check Global Cache First (expires after 1 day)
    q_hash = get_query_hash(chat_req.messages)
    cached = db_session.query(models.GlobalCache).filter(models.GlobalCache.query_hash == q_hash).first()
    
    # Expire cache older than 1 day
    if cached and cached.created_at:
        age = datetime.utcnow() - cached.created_at
        if age.total_seconds() > 86400:  # 24 hours
            db_session.delete(cached)
            db_session.flush()
            cached = None
    elif cached and not cached.created_at:
        # Old entries without timestamp — treat as expired
        db_session.delete(cached)
        db_session.flush()
        cached = None

    if cached:
        result = {"reply": cached.response_text, "total_tokens": cached.total_tokens}
    else:
        # Call AI API
        result = await generate_chat_response(chat_req.messages)
        # Store in cache
        new_cache = models.GlobalCache(query_hash=q_hash, response_text=result["reply"], total_tokens=result["total_tokens"])
        db_session.add(new_cache)
        
    # Save partial in case it didn't exist
    if not chat:
        title = chat_req.title if chat_req.title else "New Chat"
        chat = models.ChatSession(id=chat_req.chat_id, user_id=user.id, title=title, messages=chat_req.messages)
        db_session.add(chat)
        
    chat.total_tokens = result["total_tokens"]
    chat.messages = chat_req.messages + [{"role": "assistant", "content": result["reply"]}]
    db_session.commit()
    
    return {
        "message": result["reply"], 
        "total_tokens": result["total_tokens"],
        "token_limit": chat.token_limit,
        "locked_until": chat.locked_until
    }

@app.get("/api/chats")
def get_chats(request: Request, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user: raise HTTPException(status_code=401)
    chats = db.query(models.ChatSession).filter(models.ChatSession.user_id == user.id).all()
    return chats

@app.post("/api/chats")
def save_chat_state(request: Request, state: ChatSessionCreate, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user: raise HTTPException(status_code=401)
    
    chat = db.query(models.ChatSession).filter(models.ChatSession.id == state.id).first()
    if not chat:
        chat = models.ChatSession(id=state.id, user_id=user.id, project_id=state.project_id)
        db.add(chat)
    
    chat.title = state.title
    chat.messages = state.messages
    chat.total_tokens = state.total_tokens
    chat.token_limit = state.token_limit
    chat.locked_until = state.locked_until
    if state.project_id is not None:
        chat.project_id = state.project_id
    db.commit()
    return {"status": "ok"}

@app.delete("/api/chats/{chat_id}")
async def delete_chat(request: Request, chat_id: str, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    chat = db.query(models.ChatSession).filter(models.ChatSession.id == chat_id, models.ChatSession.user_id == user.id).first()
    if not chat:
        raise HTTPException(status_code=404, detail="Chat not found")
    
    db.delete(chat)
    db.commit()
    return {"status": "success"}

# Project API endpoints
@app.get("/api/projects")
async def get_projects(request: Request, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    projects = db.query(models.Project).filter(models.Project.user_id == user.id).all()
    return projects

@app.post("/api/projects")
async def create_project(request: Request, project: ProjectCreate, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    new_project = models.Project(
        user_id=user.id,
        name=project.name,
        description=project.description
    )
    db.add(new_project)
    db.commit()
    db.refresh(new_project)
    return new_project

@app.put("/api/projects/{project_id}")
async def update_project(request: Request, project_id: str, project: ProjectUpdate, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    db_project = db.query(models.Project).filter(models.Project.id == project_id, models.Project.user_id == user.id).first()
    if not db_project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    db_project.name = project.name
    db_project.description = project.description
    db.commit()
    db.refresh(db_project)
    return db_project

@app.delete("/api/projects/{project_id}")
async def delete_project(request: Request, project_id: str, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    project = db.query(models.Project).filter(models.Project.id == project_id, models.Project.user_id == user.id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Delete all chats in this project or move them to no project
    chats = db.query(models.ChatSession).filter(models.ChatSession.project_id == project_id).all()
    for chat in chats:
        chat.project_id = None
    
    db.delete(project)
    db.commit()
    return {"status": "success"}

@app.get("/api/projects/{project_id}/chats")
async def get_project_chats(request: Request, project_id: str, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    # Verify project belongs to user
    project = db.query(models.Project).filter(models.Project.id == project_id, models.Project.user_id == user.id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    
    chats = db.query(models.ChatSession).filter(models.ChatSession.project_id == project_id).all()
    return chats

class WebSearchRequest(BaseModel):
    query: str

class WebSearchResult(BaseModel):
    title: str
    url: str
    snippet: str

class FileUploadResponse(BaseModel):
    filename: str
    file_type: str
    size: int
    content: str
    is_image: bool

@app.post("/api/websearch")
async def web_search(request: WebSearchRequest, db: Session = Depends(get_db)):
    user = get_current_user_obj(request, db)
    if not user:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        # Use a more reliable web search approach
        import requests
        from urllib.parse import quote
        import re
        
        # Using Brave Search API (free tier) - you can replace with your preferred service
        # For now, let's use a more reliable approach with serpapi or similar
        search_url = f"https://api.duckduckgo.com/?q={quote(request.query)}&format=json&pretty=1"
        
        response = requests.get(search_url, timeout=10)
        results = []
        
        if response.status_code == 200:
            data = response.json()
            
            # Extract results from DuckDuckGo response
            if 'Results' in data and isinstance(data['Results'], list):
                for result in data['Results'][:5]:  # Limit to 5 results
                    snippet = result.get('Text', '')
                    # Clean up HTML tags
                    snippet = re.sub(r'<[^>]+>', '', snippet)
                    snippet = snippet[:200] + '...' if len(snippet) > 200 else snippet
                    
                    results.append({
                        "title": result.get('Title', ''),
                        "url": result.get('FirstURL', ''),
                        "snippet": snippet
                    })
            
            # If no results from DDG, try to get from RelatedTopics
            if not results and 'RelatedTopics' in data:
                for topic in data['RelatedTopics'][:5]:
                    if isinstance(topic, dict) and 'Text' in topic:
                        snippet = re.sub(r'<[^>]+>', '', topic.get('Text', ''))
                        snippet = snippet[:200] + '...' if len(snippet) > 200 else snippet
                        
                        results.append({
                            "title": topic.get('FirstURL', '').split('/')[-1] or 'Related Topic',
                            "url": topic.get('FirstURL', ''),
                            "snippet": snippet
                        })
        
        return {"results": results}
            
    except Exception as e:
        print(f"Web search error: {e}")
        # Return fallback results
        return {"results": [{
            "title": "Search temporarily unavailable",
            "url": "https://duckduckgo.com",
            "snippet": "Web search is currently experiencing issues. Please try again later."
        }]}

@app.post("/api/upload")
async def upload_file(request: Request, file: UploadFile = File(...)):
    # Check authentication using session token
    token = request.cookies.get("session_token")
    if not token:
        raise HTTPException(status_code=401, detail="Unauthorized")
    
    try:
        from jose import jwt, JWTError
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Unauthorized")
        print(f"Authenticated user: {username}")
    except JWTError as e:
        print(f"JWT Error: {e}")
        raise HTTPException(status_code=401, detail="Unauthorized")
    except Exception as e:
        print(f"Auth error: {e}")
        raise HTTPException(status_code=401, detail="Authentication failed")
    
    try:
        print(f"Processing file: {file.filename}")
        
        # Check file size (10MB limit)
        content = await file.read()
        print(f"File size: {len(content)} bytes")
        
        if len(content) > 10 * 1024 * 1024:
            raise HTTPException(status_code=413, detail="File too large. Maximum size is 10MB.")
        
        # Determine file type
        file_type = mimetypes.guess_type(file.filename)[0] or 'application/octet-stream'
        is_image = file_type.startswith('image/')
        print(f"File type: {file_type}, Is image: {is_image}")
        
        # Process file content
        if is_image:
            # For images, convert to base64
            file_content = base64.b64encode(content).decode('utf-8')
            print("Image converted to base64")
        else:
            # For text files, try to decode as text
            try:
                file_content = content.decode('utf-8')
                print("Text file decoded successfully")
            except UnicodeDecodeError:
                # If not text, return as base64
                file_content = base64.b64encode(content).decode('utf-8')
                file_type = 'application/octet-stream'
                print("Binary file converted to base64")
        
        result = FileUploadResponse(
            filename=file.filename,
            file_type=file_type,
            size=len(content),
            content=file_content,
            is_image=is_image
        )
        print(f"File processed successfully: {file.filename}")
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"File upload error: {e}")
        raise HTTPException(status_code=500, detail="File upload failed")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
