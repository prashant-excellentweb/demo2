from sqlalchemy import Column, String, Integer, BigInteger, JSON, ForeignKey, DateTime, func
from database import Base
import uuid

class User(Base):
    __tablename__ = "users"

    id = Column(String, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)
    display_name = Column(String, nullable=True)
    hashed_password = Column(String, nullable=False)

class Project(Base):
    __tablename__ = "projects"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id"))
    name = Column(String, nullable=False)
    description = Column(String, nullable=True)
    created_at = Column(DateTime, server_default=func.now())
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now())

class GlobalCache(Base):
    __tablename__ = "global_cache"

    query_hash = Column(String, primary_key=True, index=True)
    response_text = Column(String)
    total_tokens = Column(Integer)
    created_at = Column(DateTime, server_default=func.now())


class ChatSession(Base):
    __tablename__ = "chat_sessions"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey("users.id"))
    project_id = Column(String, ForeignKey("projects.id"), nullable=True)
    title = Column(String)
    messages = Column(JSON) # Store raw message array
    total_tokens = Column(Integer, default=0)
    token_limit = Column(Integer, default=1000)
    locked_until = Column(BigInteger, default=0) # JS timestamp ms
