document.addEventListener("DOMContentLoaded", async () => {
    marked.use({
        breaks: true,
        gfm: true
    });

    const chatInput = document.getElementById("chat-input");
    const sendBtn = document.getElementById("send-btn");
    const micBtn = document.getElementById("mic-btn");
    const chatContainer = document.getElementById("chat-container");
    const newChatBtn = document.getElementById("new-chat-btn");
    const newProjectBtn = document.getElementById("new-project-btn");
    const sidebarHistory = document.getElementById("chat-history");
    const projectsList = document.getElementById("projects-list");
    const profileBtn = document.getElementById("profile-btn");
    const logoHome = document.getElementById("logo-home");
    const activeChatTitleDisp = document.getElementById("active-chat-title");
    const attachBtn = document.getElementById("attach-btn");
    const websearchBtn = document.getElementById("websearch-btn");
    const fileInput = document.getElementById("file-input");
    const fileAttachments = document.getElementById("file-attachments");
    const attachmentsList = document.getElementById("attachments-list");
    const clearAttachmentsBtn = document.getElementById("clear-attachments");
    const webSearchResults = document.getElementById("web-search-results");
    const searchResultsList = document.getElementById("search-results-list");
    const clearSearchBtn = document.getElementById("clear-search");

    let chats = [];
    let projects = [];
    let currentChatId = null;
    let currentProjectId = null;
    let lockTimer = null;
    let recognition = null;
    let attachedFiles = [];
    let webSearchData = [];

    // Initialize Speech Recognition
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = false;
        recognition.lang = 'en-US';

        recognition.onstart = () => {
            micBtn.classList.add("mic-active");
        };

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            chatInput.value += (chatInput.value ? ' ' : '') + transcript;
            chatInput.dispatchEvent(new Event('input'));
        };

        recognition.onerror = () => {
             micBtn.classList.remove("mic-active");
        };

        recognition.onend = () => {
            micBtn.classList.remove("mic-active");
        };
    }

    micBtn.addEventListener("click", () => {
        if (!recognition) {
            alert("Speech recognition not supported in this browser.");
            return;
        }
        if (micBtn.classList.contains("mic-active")) {
            recognition.stop();
        } else {
            recognition.start();
        }
    });

    logoHome.addEventListener("click", startNewChat);

    // Load Projects and Chats on Startup
    await loadProjects();
    await loadChats();

    async function loadProjects() {
        try {
            const resp = await fetch('/api/projects');
            projects = await resp.json();
            renderProjects();
        } catch (e) {
            console.error("Failed to load projects from DB", e);
        }
    }

    async function loadChats() {
        try {
            const resp = await fetch('/api/chats');
            chats = await resp.json();
            renderSidebar();
            if (chats.length > 0) {
                switchChat(chats[0].id);
            } else {
                startNewChat();
            }
        } catch (e) {
            console.error("Failed to load chats from DB", e);
        }
    }

    function renderProjects() {
        projectsList.innerHTML = "";
        projects.forEach(project => {
            const projectDiv = document.createElement("div");
            projectDiv.className = "project-item";
            projectDiv.dataset.projectId = project.id;

            const headerDiv = document.createElement("div");
            headerDiv.className = "project-header";
            if (project.id === currentProjectId) headerDiv.classList.add("active");

            const icon = document.createElement("div");
            icon.className = "project-icon";
            icon.innerHTML = `<svg viewBox="0 0 24 24" fill="currentColor"><path d="M10 4H4c-1.11 0-2 .89-2 2v3h2V6h6V4zM10 19v-1H4v-4H2v5c0 1.11.89 2 2 2h6zm8-15h-6v2h6v3h2V6c0-1.11-.89-2-2-2zm2 13v-5h-2v4h-6v2h6c1.11 0 2-.89 2-2z"/></svg>`;
            headerDiv.appendChild(icon);

            const nameSpan = document.createElement("span");
            nameSpan.className = "project-name";
            nameSpan.textContent = project.name;
            headerDiv.appendChild(nameSpan);

            const actionsDiv = document.createElement("div");
            actionsDiv.className = "project-actions";

            const addChatBtn = document.createElement("button");
            addChatBtn.className = "project-action-btn";
            addChatBtn.title = "New chat in project";
            addChatBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>`;
            addChatBtn.onclick = (e) => {
                e.stopPropagation();
                startNewChatInProject(project.id);
            };
            actionsDiv.appendChild(addChatBtn);

            const deleteBtn = document.createElement("button");
            deleteBtn.className = "project-action-btn";
            deleteBtn.title = "Delete project";
            deleteBtn.innerHTML = `<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>`;
            deleteBtn.onclick = (e) => {
                e.stopPropagation();
                deleteProject(project.id);
            };
            actionsDiv.appendChild(deleteBtn);

            headerDiv.appendChild(actionsDiv);
            projectDiv.appendChild(headerDiv);

            const chatsDiv = document.createElement("div");
            chatsDiv.className = "project-chats";
            projectDiv.appendChild(chatsDiv);

            headerDiv.onclick = () => toggleProject(project.id);

            projectsList.appendChild(projectDiv);
        });
    }

    function renderSidebar() {
        // First render project chats
        projects.forEach(project => {
            const projectDiv = document.querySelector(`[data-project-id="${project.id}"]`);
            if (projectDiv) {
                const chatsDiv = projectDiv.querySelector('.project-chats');
                chatsDiv.innerHTML = "";
                
                const projectChats = chats.filter(chat => chat.project_id === project.id);
                projectChats.forEach(chat => {
                    renderChatItem(chatsDiv, chat);
                });
            }
        });

        // Then render recent chats (those not in any project)
        sidebarHistory.innerHTML = "";
        const recentChats = chats.filter(chat => !chat.project_id);
        recentChats.forEach(chat => {
            renderChatItem(sidebarHistory, chat);
        });
    }

    function renderChatItem(container, chat) {
        const div = document.createElement("div");
        div.className = "history-item";
        if (chat.id === currentChatId) div.classList.add("active");

        const titleSpan = document.createElement("span");
        titleSpan.className = "history-title";
        titleSpan.textContent = chat.title || "New Chat";
        div.appendChild(titleSpan);

        const delBtn = document.createElement("button");
        delBtn.className = "trash-btn";
        delBtn.title = "Delete chat";
        delBtn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>`;
        delBtn.onclick = (e) => {
            e.stopPropagation();
            deleteChat(chat.id);
        };
        div.appendChild(delBtn);

        div.onclick = () => switchChat(chat.id);
        container.appendChild(div);
    }

    async function deleteChat(id) {
        try {
            const resp = await fetch(`/api/chats/${id}`, { method: 'DELETE' });
            if (resp.ok) {
                chats = chats.filter(c => c.id !== id);
                if (currentChatId === id) {
                    if (chats.length > 0) switchChat(chats[0].id);
                    else startNewChat();
                } else {
                    renderSidebar();
                }
            }
        } catch (e) { console.error("Deletion failed", e); }
    }

    function startNewChat() {
        currentChatId = crypto.randomUUID();
        currentProjectId = null;
        const newChat = {
            id: currentChatId,
            title: "New Chat",
            messages: [],
            total_tokens: 0,
            token_limit: 1000,
            locked_until: 0,
            project_id: null
        };
        chats.unshift(newChat);
        renderSidebar();
        renderCurrentChat();
    }

    function startNewChatInProject(projectId) {
        currentChatId = crypto.randomUUID();
        currentProjectId = projectId;
        const project = projects.find(p => p.id === projectId);
        const newChat = {
            id: currentChatId,
            title: "New Chat",
            messages: [],
            total_tokens: 0,
            token_limit: 1000,
            locked_until: 0,
            project_id: projectId
        };
        chats.unshift(newChat);
        
        // Expand project if not already expanded
        const projectDiv = document.querySelector(`[data-project-id="${projectId}"]`);
        if (projectDiv && !projectDiv.classList.contains('expanded')) {
            toggleProject(projectId);
        }
        
        renderSidebar();
        renderCurrentChat();
        
        // Update project header active state
        document.querySelectorAll('.project-header').forEach(header => {
            header.classList.remove('active');
        });
        const activeHeader = document.querySelector(`[data-project-id="${projectId}"] .project-header`);
        if (activeHeader) activeHeader.classList.add('active');
    }

    function switchChat(id) {
        currentChatId = id;
        renderSidebar(); // Update active class
        renderCurrentChat();
    }

    function getActiveChat() {
        return chats.find(c => c.id === currentChatId);
    }

    function renderCurrentChat() {
        if(lockTimer) clearInterval(lockTimer);
        const chat = getActiveChat();
        if(!chat) return;

        chatContainer.innerHTML = "";
        if (chat.messages.length === 0) {
            chatContainer.innerHTML = `<div class="initial-message">Hello ! I am EI chat assistant.</div>`;
        } else {
            chat.messages.forEach((m, idx) => {
                appendMessage(m.role === 'assistant' ? 'bot' : 'user', m.content, idx);
            });
        }
        
        updateUIState();
        if (activeChatTitleDisp) activeChatTitleDisp.textContent = chat.title || "New Chat";
    }

    function updateUIState() {
        const chat = getActiveChat();
        if(!chat) return;

        // Update Token Visuals in Sidebar
        const countEl = document.getElementById("token-count");
        const limitEl = document.getElementById("token-limit-display");
        const progressEl = document.getElementById("token-progress");
        
        if (countEl && limitEl && progressEl) {
            countEl.textContent = chat.total_tokens.toLocaleString();
            limitEl.textContent = (chat.token_limit / 1000) + 'k';
            const pct = Math.min((chat.total_tokens / chat.token_limit) * 100, 100);
            progressEl.style.width = pct + '%';
            if (pct > 80) progressEl.classList.add("warning");
            else progressEl.classList.remove("warning");
        }

        // Context check
        const nowMs = Date.now();
        if (chat.locked_until > nowMs) {
            disableInput(chat.locked_until);
        } else if (chat.total_tokens >= chat.token_limit && chat.total_tokens > 0) {
            chat.locked_until = nowMs + (10 * 60 * 1000);
            saveChatState(chat);
            disableInput(chat.locked_until);
        } else {
            enableInput();
        }
    }

    function disableInput(unlockTimeMs) {
        chatInput.disabled = true;
        sendBtn.disabled = true;
        
        if(lockTimer) clearInterval(lockTimer);
        lockTimer = setInterval(() => {
            const left = unlockTimeMs - Date.now();
            if (left <= 0) {
                clearInterval(lockTimer);
                const chat = getActiveChat();
                chat.token_limit += 1000;
                chat.locked_until = 0;
                saveChatState(chat);
                enableInput();
                updateUIState();
                return;
            }
            const mins = Math.floor(left / 60000);
            const secs = Math.floor((left % 60000) / 1000);
            chatInput.placeholder = `Limit reached. Unlocks in ${mins}:${secs < 10 ? '0' : ''}${secs}...`;
        }, 1000);
    }

    function enableInput() {
        if(lockTimer) clearInterval(lockTimer);
        chatInput.disabled = false;
        chatInput.placeholder = "Ask anything";
        if (chatInput.value.trim() !== '') sendBtn.disabled = false;
    }

    async function saveChatState(chat) {
        await fetch('/api/chats', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({
                id: chat.id,
                title: chat.title,
                messages: chat.messages,
                total_tokens: chat.total_tokens,
                token_limit: chat.token_limit,
                locked_until: chat.locked_until,
                project_id: chat.project_id
            })
        });
    }

    newChatBtn.addEventListener("click", startNewChat);
    newProjectBtn.addEventListener("click", createProject);
    attachBtn.addEventListener("click", () => fileInput.click());
    websearchBtn.addEventListener("click", performWebSearch);
    clearAttachmentsBtn.addEventListener("click", clearAllAttachments);
    clearSearchBtn.addEventListener("click", clearWebSearch);
    fileInput.addEventListener("change", handleFileSelect);

    chatInput.addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = (this.scrollHeight) + 'px';
        if (this.value.trim() !== '') {
            sendBtn.disabled = false;
            sendBtn.classList.add("active");
        } else {
            sendBtn.disabled = true;
            sendBtn.classList.remove("active");
        }
    });

    chatInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            if (!sendBtn.disabled) sendBtn.click();
        }
    });

    sendBtn.addEventListener("click", async () => {
        const message = chatInput.value.trim();
        if (!message && attachedFiles.length === 0 && webSearchData.length === 0) return;

        const chat = getActiveChat();
        if (chat.messages.length === 0) {
            chat.title = message.substring(0, 30) + "...";
            renderSidebar();
        }

        // Build enhanced message with attachments and web search
        let enhancedMessage = message;
        const attachments = [];
        
        // Add file information to message
        if (attachedFiles.length > 0) {
            attachments.push(...attachedFiles.map(file => ({
                name: file.filename,
                size: file.size,
                type: file.file_type,
                content: file.content,
                is_image: file.is_image
            })));
            
            const fileText = attachedFiles.map(file => {
                if (file.is_image) {
                    return `[IMAGE: ${file.filename}]\nData: ${file.content.substring(0, 100)}...`;
                } else {
                    const content = file.content.length > 2000 ? file.content.substring(0, 2000) + '...' : file.content;
                    return `[FILE: ${file.filename}]\n${content}`;
                }
            }).join('\n\n');
            
            enhancedMessage = message + '\n\n' + fileText;
        }
        
        // Add web search results to message
        if (webSearchData.length > 0) {
            const searchText = webSearchData.map(result => 
                `[WEB SEARCH: ${result.title}]\n${result.snippet}\nSource: ${result.url}`
            ).join('\n\n');
            
            enhancedMessage = enhancedMessage + '\n\n' + searchText;
        }

        chat.messages.push({ 
            role: "user", 
            content: enhancedMessage,
            attachments: attachments,
            web_search_results: webSearchData
        });
        
        appendMessage('user', message);
        chatInput.value = '';
        chatInput.style.height = 'auto';
        sendBtn.disabled = true;
        sendBtn.classList.remove("active");
        
        // Clear attachments and web search after sending
        clearAllAttachments();
        clearWebSearch();

        const typingId = appendTypingIndicator();

        try {
            const response = await fetch('/api/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    chat_id: chat.id, 
                    messages: chat.messages,
                    title: chat.title 
                })
            });

            const data = await response.json();
            const typingEl = document.getElementById(typingId);
            if(typingEl) typingEl.remove();
            
            if (response.ok) {
                chat.messages.push({ role: "assistant", content: data.message });
                chat.total_tokens = data.total_tokens;
                chat.token_limit = data.token_limit || chat.token_limit;
                chat.locked_until = data.locked_until || chat.locked_until;
                
                appendMessage('bot', data.message);
            } else {
                chat.messages.pop();
                appendMessage('bot', 'Error: ' + (data.detail || 'Request failed.'));
            }
            updateUIState();
        } catch (error) {
            chat.messages.pop();
            const typingEl = document.getElementById(typingId);
            if(typingEl) typingEl.remove();
            appendMessage('bot', 'Network error. Please try again.');
        }
    });

    function appendMessage(sender, text, msgIndex) {
        const msgDiv = document.createElement("div");
        msgDiv.className = `chat-message ${sender}`;
        
        // Remove initial message if it exists
        const initial = document.querySelector(".initial-message");
        if(initial) initial.remove();

        let contentHtml;
        if (sender === 'bot') {
            contentHtml = marked.parse(text);
        } else {
            // For user messages, handle images and text
            contentHtml = processUserMessageContent(text);
        }

        let actionsHtml = '';
        if (sender === 'bot') {
            actionsHtml = `<div class="msg-actions">
                <button class="msg-action-btn copy-btn" title="Copy response">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
                    <span>Copy</span>
                </button>
            </div>`;
        } else {
            actionsHtml = `<div class="msg-actions">
                <button class="msg-action-btn edit-btn" title="Edit & resend">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
                    <span>Edit</span>
                </button>
            </div>`;
        }

        msgDiv.innerHTML = `<div class="message-inner markdown-body">${contentHtml}</div>${actionsHtml}`;
        msgDiv.dataset.rawText = text;
        if (msgIndex !== undefined) msgDiv.dataset.msgIndex = msgIndex;

        // Wire up copy button
        const copyBtn = msgDiv.querySelector('.copy-btn');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => {
                navigator.clipboard.writeText(text).then(() => {
                    const label = copyBtn.querySelector('span');
                    label.textContent = 'Copied!';
                    setTimeout(() => { label.textContent = 'Copy'; }, 2000);
                });
            });
        }

        // Wire up edit button
        const editBtn = msgDiv.querySelector('.edit-btn');
        if (editBtn) {
            editBtn.addEventListener('click', () => {
                const idx = parseInt(msgDiv.dataset.msgIndex);
                const chat = getActiveChat();
                if (!chat || isNaN(idx)) return;

                // Put the original text into the input
                chatInput.value = text;
                chatInput.dispatchEvent(new Event('input'));
                chatInput.focus();

                // Remove this message and everything after it
                chat.messages = chat.messages.slice(0, idx);
                renderCurrentChat();
            });
        }

        chatContainer.appendChild(msgDiv);
        scrollToBottom();
    }

    function appendTypingIndicator() {
        const typingId = 'typing-' + Date.now();
        const msgDiv = document.createElement("div");
        msgDiv.className = `chat-message bot`;
        msgDiv.id = typingId;
        msgDiv.innerHTML = `<div class="message-inner"><div class="typing-indicator"><div class="dots-flow">...</div></div></div>`;
        chatContainer.appendChild(msgDiv);
        scrollToBottom();
        return typingId;
    }

    function scrollToBottom() {
        document.querySelector(".chat-viewport").scrollTop = document.querySelector(".chat-viewport").scrollHeight;
    }

    function escapeHtml(unsafe) {
        return unsafe.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
    }

    // Modal behavior
    const settingsModal = document.getElementById("settings-modal");
    const closeBtnX = document.getElementById("close-modal-x");
    const saveSettingsBtn = document.getElementById("save-settings-btn");
    const settingsMsg = document.getElementById("settings-msg");

    if (profileBtn) {
        profileBtn.addEventListener("click", () => settingsModal.classList.add("active"));
        closeBtnX.addEventListener("click", () => settingsModal.classList.remove("active"));
        
        saveSettingsBtn.addEventListener("click", async () => {
            const dn = document.getElementById("setting-display-name").value;
            const pwd = document.getElementById("setting-password").value;
            saveSettingsBtn.disabled = true;
            settingsMsg.textContent = "Saving...";
            
            try {
                const res = await fetch('/api/user/update', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({ display_name: dn, password: pwd || null })
                });
                const data = await res.json();
                if(res.ok) {
                    settingsMsg.style.color = "#10b981";
                    settingsMsg.textContent = "Updated successfully!";
                    setTimeout(() => location.reload(), 1000);
                } else {
                    settingsMsg.style.color = "#ef4444";
                    settingsMsg.textContent = data.detail || "Error";
                }
            } catch(e) { settingsMsg.textContent = "Error"; }
            saveSettingsBtn.disabled = false;
        });
    }

    // Project Management Functions
    function toggleProject(projectId) {
        const projectDiv = document.querySelector(`[data-project-id="${projectId}"]`);
        if (projectDiv) {
            projectDiv.classList.toggle('expanded');
        }
    }

    async function createProject() {
        const name = prompt('Enter project name:');
        if (!name || !name.trim()) return;
        
        const description = prompt('Enter project description (optional):');
        
        try {
            const resp = await fetch('/api/projects', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({
                    name: name.trim(),
                    description: description || null
                })
            });
            
            if (resp.ok) {
                const newProject = await resp.json();
                projects.push(newProject);
                renderProjects();
            } else {
                const data = await resp.json();
                alert('Error creating project: ' + (data.detail || 'Unknown error'));
            }
        } catch (e) {
            console.error('Failed to create project', e);
            alert('Failed to create project. Please try again.');
        }
    }

    async function deleteProject(projectId) {
        if (!confirm('Are you sure you want to delete this project? Chats will be moved to Recent Chats.')) {
            return;
        }
        
        try {
            const resp = await fetch(`/api/projects/${projectId}`, { method: 'DELETE' });
            if (resp.ok) {
                projects = projects.filter(p => p.id !== projectId);
                // Move chats from this project to recent chats
                chats.forEach(chat => {
                    if (chat.project_id === projectId) {
                        chat.project_id = null;
                    }
                });
                
                if (currentProjectId === projectId) {
                    currentProjectId = null;
                }
                
                renderProjects();
                renderSidebar();
            } else {
                const data = await resp.json();
                alert('Error deleting project: ' + (data.detail || 'Unknown error'));
            }
        } catch (e) {
            console.error('Failed to delete project', e);
            alert('Failed to delete project. Please try again.');
        }
    }

    // File Upload Functions
    async function handleFileSelect(event) {
        const files = Array.from(event.target.files);
        
        for (const file of files) {
            if (file.size > 10 * 1024 * 1024) { // 10MB limit
                alert(`File ${file.name} is too large. Maximum size is 10MB.`);
                continue;
            }
            
            try {
                // Upload file to server
                const formData = new FormData();
                formData.append('file', file);
                
                const response = await fetch('/api/upload', {
                    method: 'POST',
                    body: formData,
                    credentials: 'include'
                });
                
                if (!response.ok) {
                    try {
                        const error = await response.json();
                        const errorMessage = error.detail || error.message || 'Unknown error';
                        alert(`Upload failed: ${errorMessage}`);
                    } catch (parseError) {
                        alert(`Upload failed: Server error (${response.status})`);
                    }
                    continue;
                }
                
                const fileData = await response.json();
                
                // Add client-side ID for tracking
                fileData.id = Date.now() + Math.random().toString(36);
                attachedFiles.push(fileData);
                renderAttachments();
                
            } catch (error) {
                console.error('File upload error:', error);
                const errorMessage = error.message || 'Network error occurred';
                alert(`Upload failed for ${file.name}: ${errorMessage}. Please try again.`);
            }
        }
        
        event.target.value = ''; // Clear input
    }

    function renderAttachments() {
        if (attachedFiles.length === 0) {
            fileAttachments.style.display = 'none';
            return;
        }
        
        fileAttachments.style.display = 'block';
        attachmentsList.innerHTML = '';
        
        attachedFiles.forEach(file => {
            const item = document.createElement('div');
            item.className = 'attachment-item';
            
            const icon = document.createElement('div');
            icon.className = 'attachment-icon';
            icon.innerHTML = getFileIcon(file.file_type || file.type);
            
            const name = document.createElement('div');
            name.className = 'attachment-name';
            name.textContent = file.filename || file.name;
            
            const size = document.createElement('div');
            size.className = 'attachment-size';
            size.textContent = formatFileSize(file.size);
            
            const removeBtn = document.createElement('button');
            removeBtn.className = 'remove-attachment';
            removeBtn.innerHTML = '×';
            removeBtn.onclick = () => removeAttachment(file.id);
            
            item.appendChild(icon);
            item.appendChild(name);
            item.appendChild(size);
            item.appendChild(removeBtn);
            attachmentsList.appendChild(item);
        });
    }

    function removeAttachment(fileId) {
        attachedFiles = attachedFiles.filter(f => f.id !== fileId);
        renderAttachments();
    }

    function clearAllAttachments() {
        attachedFiles = [];
        fileAttachments.style.display = 'none';
        attachmentsList.innerHTML = '';
    }

    function getFileIcon(fileType) {
        if (fileType.startsWith('image/')) {
            return '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M21 19V5c0-1.1-.9-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6V8.5z"/></svg>';
        } else if (fileType.includes('pdf')) {
            return '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-1 8l-3 3v2h3v-2l3-3h-3z"/></svg>';
        } else if (fileType.includes('text')) {
            return '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-2 8l-3 3v2h3v-2l3-3h-3z"/></svg>';
        } else {
            return '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M10 4H4c-1.11 0-2 .89-2 2v12c0 1.11.89 2 2 2h16c1.11 0 2-.89 2-2V8c0-1.11-.89-2-2-2zm-1 8l-3 3v2h3v-2l3-3h-3z"/></svg>';
        }
    }

    function formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }

    // Web Search Functions
    async function performWebSearch() {
        const query = prompt('Enter search query:');
        if (!query || !query.trim()) return;
        
        try {
            const response = await fetch('/api/websearch', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({ query: query.trim() })
            });
            
            if (response.ok) {
                const data = await response.json();
                webSearchData = data.results || [];
                renderWebSearchResults();
            } else {
                alert('Web search failed. Please try again.');
            }
        } catch (error) {
            console.error('Web search error:', error);
            alert('Web search failed. Please try again.');
        }
    }

    function renderWebSearchResults() {
        if (webSearchData.length === 0) {
            webSearchResults.style.display = 'none';
            return;
        }
        
        webSearchResults.style.display = 'block';
        searchResultsList.innerHTML = '';
        
        webSearchData.forEach(result => {
            const item = document.createElement('div');
            item.className = 'search-result-item';
            item.onclick = () => {
                chatInput.value += `\n\nBased on web search: ${result.title}\n${result.snippet}\nSource: ${result.url}\n\n`;
                chatInput.dispatchEvent(new Event('input'));
            };
            
            const title = document.createElement('div');
            title.className = 'search-result-title';
            title.textContent = result.title;
            
            const url = document.createElement('div');
            url.className = 'search-result-url';
            url.textContent = new URL(result.url).hostname;
            
            const snippet = document.createElement('div');
            snippet.className = 'search-result-snippet';
            snippet.textContent = result.snippet;
            
            item.appendChild(title);
            item.appendChild(url);
            item.appendChild(snippet);
            searchResultsList.appendChild(item);
        });
    }

    function clearWebSearch() {
        webSearchData = [];
        webSearchResults.style.display = 'none';
        searchResultsList.innerHTML = '';
    }

    function processUserMessageContent(text) {
        // Process user message content to handle images and formatting
        let processedText = escapeHtml(text).replace(/\n/g, '<br>');
        
        // Find and replace image references with actual images
        processedText = processedText.replace(
            /\[IMAGE: ([^\]]+)\]\nData: ([^\n]+)\.\.\./g,
            (match, filename, dataUrl) => {
                // Try to find the full data URL from attached files
                const file = attachedFiles.find(f => f.filename === filename && f.is_image);
                if (file && file.content.startsWith('data:image')) {
                    return `<div class="attached-image">
                        <img src="${file.content}" alt="${filename}" style="max-width: 200px; max-height: 200px; border-radius: 8px; margin: 4px 0;">
                        <div class="image-caption" style="font-size: 11px; color: var(--text-muted); margin-top: 4px;">${filename}</div>
                    </div>`;
                }
                return match;
            }
        );
        
        // Handle file attachments
        processedText = processedText.replace(
            /\[FILE: ([^\]]+)\]([^]*?)(?=\n\n|$)/g,
            (match, filename, content) => {
                const file = attachedFiles.find(f => f.filename === filename && !f.is_image);
                if (file) {
                    const preview = content.length > 200 ? content.substring(0, 200) + '...' : content;
                    return `<div class="attached-file">
                        <div class="file-header" style="font-weight: 500; margin-bottom: 4px;">? ${filename}</div>
                        <div class="file-preview" style="font-size: 12px; color: var(--text-muted); background: rgba(255,255,255,0.05); padding: 8px; border-radius: 4px; margin-bottom: 8px;">${escapeHtml(preview)}</div>
                    </div>`;
                }
                return match;
            }
        );
        
        return processedText;
    }
});
